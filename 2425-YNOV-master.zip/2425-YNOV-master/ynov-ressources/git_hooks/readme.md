Les fichiers présents dans ce dossier sont des **exemples** de hooks GIT avec DVC.  

Ils sont installés (simple copier/coller) par défaut à l'initialisation du package via `make init-local-env`.  

Ce ne sont donc pas directement les hooks utilisés par GIT. Si vous souhaitez modifier les hooks, il faut éditer ceux présents dans `.git/hooks/`.